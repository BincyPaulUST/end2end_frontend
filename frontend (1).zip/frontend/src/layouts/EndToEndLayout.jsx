import React from "react";
import { Outlet } from "react-router-dom";
import Header from "../components/layoutComponents/Header";
import Sidebar from "../components/layoutComponents/Sidebar";
import Footer from "../components/layoutComponents/Footer";

const EndToEndLayout = () => {
  return (
    <div
      className="flex flex-col min-h-screen"
      style={{ fontFamily: "poppins" }}
    >
      <Header />
      <div className="flex flex-1 z-10 mt-15 mb-15">
        <Sidebar />
        <main className="flex-grow p-3 bg-white">
          <Outlet />
        </main>
      </div>
      <Footer />
    </div>
  );
};

export default EndToEndLayout;
