import { Box, Divider, Typography } from "@mui/material";
import React from "react";

const GraphPage = () => {
  return (
    <div>
      <Box sx={{ paddingTop: "20px", paddingBottom: "10px" }}>
        <Typography variant="h5">Generate Graph</Typography>
        <Divider />
      </Box>
    </div>
  );
};

export default GraphPage;
