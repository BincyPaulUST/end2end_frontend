import { Box } from "@mui/material";
import React from "react";
import HorizontalLinearStepper from "../components/Stepper";
import MainTabGroup from "../components/MainTabGroup";

const EndToEndFlow = () => {
  return (
    <Box sx={{ maxWidth: "100%", boxSizing: "border-box" }}>
      <HorizontalLinearStepper />
      <MainTabGroup />
    </Box>
  );
};

export default EndToEndFlow;
