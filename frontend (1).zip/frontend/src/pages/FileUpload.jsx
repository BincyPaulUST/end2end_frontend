import React, { useState, useRef, useEffect } from "react";
import axios from "axios";
import {
  Box,
  Container,
  RadioGroup,
  FormControlLabel,
  Radio,
  Button,
  Snackbar,
  Alert,
  CircularProgress,
  Typography,
  CssBaseline,
  Divider,
  List,
  ListItem,
  ListItemText,
} from "@mui/material";

function FileUpload() {
  const [isDragging, setIsDragging] = useState(false);
  const [fileName, setFileName] = useState("");
  const [file, setFile] = useState(null);
  const [inputType, setInputType] = useState("document");
  const [toastOpen, setToastOpen] = useState(false);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0); // State for upload progress
  const [selectedPage, setSelectedPage] = useState("upload");
  const fileInputRef = useRef(null);

  // ________________________________________________File Listing
  const [files, setFiles] = useState([]);
  const [toastOpenList, setToastOpenList] = useState(false);
  const [toastMessage, setToastMessage] = useState("");
  const [toastSeverity, setToastSeverity] = useState("success"); // 'success' | 'error'

  const fetchFiles = async () => {
    try {
      const response = await axios.get(
        "https://j29qw5k3b7-vpce-070c8384f2397b727.execute-api.eu-west-2.amazonaws.com/end-to-end-flow-stage/list"
      ); // Backend `/list` API
      setFiles(response.data.files);
      console.log(response.data);
    } catch (err) {
      setToastMessage("Error fetching files.");
      setToastSeverity("error");
      setToastOpenList(true);
    }
  };

  // Delete a file
  const deleteFile = async (fileName) => {
    console.log(fileName);
    try {
      const response = await axios.delete(
        "https://j29qw5k3b7-vpce-070c8384f2397b727.execute-api.eu-west-2.amazonaws.com/end-to-end-flow-stage/delete",
        { data: { s3_key: fileName } }
      );
      setToastMessage(response.data.message);
      setToastSeverity("success");
      setToastOpenList(true);
      fetchFiles();
    } catch (err) {
      setToastMessage("Error deleting file.");
      setToastSeverity("error");
      setToastOpenList(true);
    }
  };

  // Handle Snackbar close
  const handleToastCloseList = (event, reason) => {
    if (reason === "clickaway") return;
    setToastOpenList(false);
  };

  // ____________________________________________________________________

  const allowedFileTypes = {
    document: [
      "application/pdf",
      "application/msword",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ],
    image: ["image/png", "image/jpeg", "image/jpg", "image/gif"],
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragEnter = (e) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragging(false);
    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile) {
      validateAndSetFile(droppedFile);
    }
  };

  const handleFileClick = () => {
    fileInputRef.current.click();
  };

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      validateAndSetFile(selectedFile);
    }
  };

  const validateAndSetFile = (selectedFile) => {
    if (allowedFileTypes[inputType].includes(selectedFile.type)) {
      setFile(selectedFile);
      setFileName(selectedFile.name);
      setError(null);
    } else {
      setFile(null);
      setFileName("");
      setError(`Invalid file type for. Please upload a valid file.`);
    }
  };

  const handleUpload = async () => {
    if (file) {
      const formData = new FormData();
      formData.append("file", file);

      setLoading(true);
      try {
        await axios.post(
          "https://j29qw5k3b7-vpce-070c8384f2397b727.execute-api.eu-west-2.amazonaws.com/end-to-end-flow-stage/upload",
          formData,
          {
            headers: {
              "Content-Type": "multipart/form-data",
            },
            onUploadProgress: (progressEvent) => {
              const percentCompleted = Math.round(
                (progressEvent.loaded * 100) / progressEvent.total
              );
              setUploadProgress(percentCompleted);
            },
          }
        );
        setToastOpen(true);
        setFile(null);
        setFileName("");
        fetchFiles();
      } catch (err) {
        setError("Failed to upload file. Please try again.");
      } finally {
        setLoading(false);
        setUploadProgress(0); // Reset upload progress
      }
    } else {
      setError("No file selected for upload.");
    }
  };

  const handleToastClose = () => {
    setToastOpen(false);
  };

  useEffect(() => {
    fetchFiles();
  }, []);

  return (
    <Box>
      <CssBaseline />
      <Box sx={{ paddingTop: "20px", paddingBottom: "10px" }}>
        <Typography variant="h5">File Upload</Typography>
        <Divider />
      </Box>
      <Box
        sx={{
          display: "flex",
          flexGrow: 1,
        }}
      >
        <Box
          component="main"
          sx={{
            flexGrow: 1,
            backgroundColor: "white",
            overflow: "auto",
          }}
        >
          <br />
          <br />
          {selectedPage === "upload" && (
            <Container style={{ maxWidth: "800px" }}>
              {/* Drag and Drop File Upload */}
              <div
                style={{
                  borderRadius: "4px",
                  border: "1.8px dashed #0097AB",
                  padding: "16px",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  cursor: "pointer",
                  backgroundColor: isDragging ? "#f0faff" : "transparent",
                }}
                onDragOver={handleDragOver}
                onDragEnter={handleDragEnter}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                onClick={handleFileClick}
              >
                <div style={{ textAlign: "center", color: "black" }}>
                  <Typography variant="body1" style={{ fontWeight: 12 }}>
                    {fileName ? fileName : `Drag & Drop your file here`}
                  </Typography>
                  <Typography variant="body2" style={{ color: "gray" }}>
                    or
                    <span
                      style={{
                        fontWeight: 700,
                        color: "#0097AB",
                        cursor: "pointer",
                        marginLeft: "4px",
                      }}
                    >
                      Upload from computer
                    </span>
                  </Typography>
                  <input
                    type="file"
                    hidden
                    ref={fileInputRef}
                    onChange={handleFileChange}
                  />
                </div>
              </div>

              {/* Error Message */}
              {error && (
                <Typography
                  variant="body2"
                  color="error"
                  style={{ marginTop: "10px" }}
                >
                  {error}
                </Typography>
              )}

              {/* Upload Button */}
              <Box textAlign="center" mt={2}>
                {loading ? (
                  <Box
                    sx={{
                      position: "relative",
                      display: "inline-flex",
                      flexDirection: "column",
                      alignItems: "center",
                    }}
                  >
                    <CircularProgress
                      variant="determinate"
                      value={uploadProgress}
                    />
                    <Box
                      sx={{
                        top: 0,
                        left: 0,
                        bottom: 0,
                        right: 0,
                        position: "absolute",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                      }}
                    >
                      <Typography
                        variant="caption"
                        component="div"
                        sx={{ color: "text.secondary" }}
                      >
                        {`${Math.round(uploadProgress)}%`}
                      </Typography>
                    </Box>
                    {/* Add "Uploading..." text below the progress bar */}
                    <Typography
                      variant="body2"
                      sx={{ mt: 1, color: "text.secondary" }}
                    >
                      Uploading...
                    </Typography>
                  </Box>
                ) : (
                  <Button
                    variant="contained"
                    style={{ backgroundColor: "#0097AB", color: "white" }}
                    onClick={handleUpload}
                    disabled={!file}
                  >
                    Upload
                  </Button>
                )}
              </Box>

              {/* Toast Message */}
              <Snackbar
                open={toastOpen}
                autoHideDuration={3000}
                onClose={handleToastClose}
                anchorOrigin={{ vertical: "top", horizontal: "right" }}
              >
                <Alert
                  onClose={handleToastClose}
                  autoHideDuration={3000}
                  severity="success"
                  sx={{ width: "100%" }}
                >
                  File uploaded successfully!
                </Alert>
              </Snackbar>
            </Container>
          )}

          <Container>
            <>
              <Typography
                variant="h5"
                gutterBottom
                align="center"
                sx={{ fontWeight: "bold", color: "#333" }}
              >
                Uploaded Files
              </Typography>
              <Box
                sx={{
                  maxWidth: 900,
                  margin: "20px auto",
                  padding: "20px",
                  border: "1px solid #ccc",
                  borderRadius: "8px",
                  boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
                  backgroundColor: "#f9f9f9",
                }}
              >
                <List>
                  {files.length > 0 ? (
                    files.map((file, index) => (
                      <ListItem
                        key={index}
                        sx={{
                          display: "flex",
                          justifyContent: "space-between",
                          alignItems: "center",
                          borderBottom: "1px solid #ddd",
                          padding: "8px 0",
                        }}
                      >
                        <ListItemText
                          primary={file?.filename}
                          sx={{ color: "#555" }}
                        />
                        <Box>
                          {/* Open Button */}
                          <Button
                            variant="outlined"
                            color="primary"
                            sx={{ marginRight: 1, textTransform: "none" }}
                            component="a" // Use an anchor element
                            href={file?.download_url} // Set the download URL
                            download // Force download instead of opening in a new tab
                            target="_blank" // Open in a new tab (optional)
                            onClick={() => {
                              try {
                                setToastMessage(
                                  `Downloading file: ${file?.filename}`
                                );
                                setToastSeverity("success");
                                setToastOpenList(true);
                              } catch (err) {
                                setToastMessage(
                                  `Failed to download file: ${file?.filename}`
                                );
                                setToastSeverity("error");
                                setToastOpenList(true);
                              }
                            }}
                          >
                            Download
                          </Button>

                          {/* Delete Button */}
                          <Button
                            variant="outlined"
                            color="error"
                            sx={{
                              fontWeight: "bold",
                              textTransform: "none",
                              "&:hover": {
                                backgroundColor: "#ffe6e6",
                              },
                            }}
                            onClick={() => deleteFile(file?.filename)}
                          >
                            Delete
                          </Button>
                        </Box>
                      </ListItem>
                    ))
                  ) : (
                    <ListItem>
                      <ListItemText
                        primary="No files found"
                        sx={{ color: "#888" }}
                      />
                    </ListItem>
                  )}
                </List>

                {/* Snackbar for notifications */}
                <Snackbar
                  open={toastOpen}
                  autoHideDuration={3000}
                  onClose={handleToastCloseList}
                  anchorOrigin={{ vertical: "top", horizontal: "right" }}
                >
                  <Alert
                    onClose={handleToastCloseList}
                    severity={toastSeverity}
                    sx={{ width: "100%" }}
                  >
                    {toastMessage}
                  </Alert>
                </Snackbar>
              </Box>
            </>
          </Container>
        </Box>
      </Box>
    </Box>
  );
}

export default FileUpload;
