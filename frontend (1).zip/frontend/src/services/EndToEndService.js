import api from "./api";

export const endToEndService = {
  fetchFromRag: async (data) => {
    try {
      const response = await api.post(
        `/rag_retriever`,

        data,

        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      if (response) {
        return Promise.resolve(response.data);
      } else {
        return Promise.reject({
          message: `Error ${response}`,
        });
      }
    } catch (error) {
      console.error("Error :", error);

      return Promise.reject({
        message: "Internal Server Error",

        details: error,
      });
    }
  },

  FetchRequirements: async (data) => {
    try {
      const response = await api.post(
        `/requirements`,

        data,

        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      if (response) {
        return Promise.resolve(response.data);
      } else {
        return Promise.reject({
          message: `Error ${response}`,
        });
      }
    } catch (error) {
      console.error("Error :", error);

      return Promise.reject({
        message: "Internal Server Error",

        details: error,
      });
    }
  },
  FetchUserStories: async (data) => {
    try {
      const response = await api.post(
        `/user_story`,

        data,

        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      if (response) {
        return Promise.resolve(response.data);
      } else {
        return Promise.reject({
          message: `Error ${response}`,
        });
      }
    } catch (error) {
      console.error("Error :", error);

      return Promise.reject({
        message: "Internal Server Error",

        details: error,
      });
    }
  },
  FetchBdd: async (data) => {
    try {
      const response = await api.post(
        `/bdd_gen`,

        data,

        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      if (response) {
        return Promise.resolve(response.data);
      } else {
        return Promise.reject({
          message: `Error ${response}`,
        });
      }
    } catch (error) {
      console.error("Error :", error);

      return Promise.reject({
        message: "Internal Server Error",

        details: error,
      });
    }
  },
  FetchTestCases: async (data) => {
    try {
      const response = await api.post(
        `/test_case_gen`,

        data,

        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      if (response) {
        return Promise.resolve(response.data);
      } else {
        return Promise.reject({
          message: `Error ${response}`,
        });
      }
    } catch (error) {
      console.error("Error :", error);

      return Promise.reject({
        message: "Internal Server Error",

        details: error,
      });
    }
  },

  FetchEpics: async () => {
    try {
      const response = await api.get(`/get_epics`, {
        headers: {
          "Content-Type": "application/json",
        },
      });

      if (response) {
        return Promise.resolve(response.data);
      } else {
        return Promise.reject({
          message: `Error ${response}`,
        });
      }
    } catch (error) {
      console.error("Error :", error);

      return Promise.reject({
        message: "Internal Server Error",

        details: error,
      });
    }
  },
  FetchPushToJira: async (data) => {
    try {
      const response = await api.post(
        `/push_user_stories`,

        data,

        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      if (response) {
        return Promise.resolve(response.data);
      } else {
        return Promise.reject({
          message: `Error ${response}`,
        });
      }
    } catch (error) {
      console.error("Error :", error);

      return Promise.reject({
        message: "Internal Server Error",

        details: error,
      });
    }
  },
};
