import axios from "axios";

const BASE_URL =
  "https://j29qw5k3b7-vpce-070c8384f2397b727.execute-api.eu-west-2.amazonaws.com/end-to-end-flow-stage";

const api = axios.create({
  baseURL: BASE_URL,
  headers: {
    "Content-Type": "application/json",
  },
});

export default api;
