import "./App.css";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import EndToEndLayout from "./layouts/EndToEndLayout";
import LoginPage from "./pages/LoginPage";
import NotFound from "./pages/NotFound";
import EndToEndFlow from "./pages/EndToEndFlow";
import GraphPage from "./pages/GraphPage";
import FileUpload from "./pages/FileUpload";
import AuthGuard from "./components/authRouters/AuthGuard";
import PublicRoute from "./components/authRouters/PublicRoute";
import { AuthProvider } from "./context/AuthContext";
import { DataProvider } from "./context/DataContext";

const router = createBrowserRouter([
  {
    path: "/",
    element: (
      <AuthGuard>
        <EndToEndLayout />
      </AuthGuard>
    ),
    // errorElement: <NotFound />,
    children: [
      {
        index: true,
        element: <EndToEndFlow />,
      },
      {
        path: "service/graph",
        element: <GraphPage />,
      },
      {
        path: "service/file-upload",
        element: <FileUpload />,
      },
    ],
  },
  {
    path: "/register",
    element: (
      <PublicRoute>
        <RegistrationPage />
      </PublicRoute>
    ),
  },
  {
    path: "/login",
    element: (
      <PublicRoute>
        <LoginPage />
      </PublicRoute>
    ),
  },
  {
    path: "*",
    element: (
      <PublicRoute>
        <LoginPage />
      </PublicRoute>
    ),
  },
]);

import { createTheme, ThemeProvider } from "@mui/material/styles";
import { ConfigurationProvider } from "./context/ConfigurationContext";
import RegistrationPage from "./pages/RegistrationPage";

const theme = createTheme({
  typography: {
    fontFamily: ["poppins", "Karla", "sans-serif"].join(","),
  },
});

function App() {
  return (
    <ConfigurationProvider>
      <DataProvider>
        <AuthProvider>
          <ThemeProvider theme={theme}>
            <RouterProvider router={router} />{" "}
          </ThemeProvider>
        </AuthProvider>
      </DataProvider>
    </ConfigurationProvider>
  );
}

export default App;
