import React, { createContext, useState, useContext, useEffect } from "react";

const ConfigurationContext = createContext();

export const ConfigurationProvider = ({ children }) => {
  const [selectedValue, setSelectedValue] = React.useState("No");
  const [epicId, setEpicId] = useState("");
  const [jiraPrompt, setJiraPrompt] = useState("");
  const [jiraSummary, setJiraSummary] = useState("");
  const [generateBDD, setGenerateBDD] = React.useState(false);
  const [generateTestScripts, setGenerateTestScripts] = React.useState(false);
  const [isjiraSelected, setIsJiraSelected] = React.useState(false);
  const [isRunAuto, setIsRunAuto] = React.useState(false);

  return (
    <ConfigurationContext.Provider
      value={{
        selectedValue,
        setSelectedValue,
        generateBDD,
        setGenerateBDD,
        generateTestScripts,
        setGenerateTestScripts,
        epicId,
        setEpicId,
        jiraPrompt,
        setJiraPrompt,
        jiraSummary,
        setJiraSummary,
        isjiraSelected,
        setIsJiraSelected,
        isRunAuto,
        setIsRunAuto,
      }}
    >
      {children}
    </ConfigurationContext.Provider>
  );
};

export { ConfigurationContext };
