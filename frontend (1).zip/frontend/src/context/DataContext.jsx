import React, { createContext, useState, useContext, useEffect } from "react";

const DataContext = createContext();

export const DataProvider = ({ children }) => {
  const [message, setMessage] = useState("");
  const [fetchedContent, setFetchedContent] = useState("");
  const [requirements, setRequirements] = useState("");
  const [activeStep, setActiveStep] = useState(0);
  const [userStories, setUserStories] = useState({});
  const [requirementLoading, setRequirementLoading] = useState(false);
  const [userStoryLoading, setUserStoryLoading] = useState(false);
  const [bdd, setBdd] = useState({});
  const [bddLoading, setBddLoading] = useState(false);
  const [testCases, setTestCases] = useState({});
  const [testCasesLoading, setTestCasesLoading] = useState(false);
  const [integration, setIntegration] = useState({});
  const [integrationStatus, setIntegrationStatus] = useState(false);

  return (
    <DataContext.Provider
      value={{
        message,
        setMessage,
        fetchedContent,
        setFetchedContent,
        requirements,
        setRequirements,
        activeStep,
        setActiveStep,
        userStories,
        setUserStories,
        requirementLoading,
        setRequirementLoading,
        userStoryLoading,
        setUserStoryLoading,
        bdd,
        setBdd,
        bddLoading,
        setBddLoading,
        testCases,
        setTestCases,
        testCasesLoading,
        setTestCasesLoading,
        integration,
        setIntegration,
        integrationStatus,
        setIntegrationStatus,
      }}
    >
      {children}
    </DataContext.Provider>
  );
};

export { DataContext };
