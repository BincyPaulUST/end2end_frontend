import React, { useContext, useState } from "react";

import { DataContext } from "../context/DataContext";

import Markdown from "react-markdown";

import { Box, Button, Divider, Typography } from "@mui/material";

import { ConfigurationContext } from "../context/ConfigurationContext";

import EditOutlinedIcon from "@mui/icons-material/EditOutlined";

import SaveOutlinedIcon from "@mui/icons-material/SaveOutlined";

const UserStory = ({
  handleGenerateBdd,

  handleGenerateTestCases,

  handlePushToJira,
  isPushed,
}) => {
  const { userStories, setUserStories } = useContext(DataContext);
  const { isRunAuto } = useContext(ConfigurationContext);
  const [editingStoryIndex, setEditingStoryIndex] = useState(-1);
  const [editingField, setEditingField] = useState(null);
  const [editValue, setEditValue] = useState("");

  const handleGenerateBddTestScript = () => {
    handleGenerateBdd();

    handleGenerateTestCases();
  };

  const handleStartEditing = (storyIndex, field, value) => {
    setEditingStoryIndex(storyIndex);

    setEditingField(field);

    // Format the value for better editing experience

    if (field === "acceptanceCriteria") {
      // Format acceptance criteria for editing

      let formattedValue = "";

      if (Array.isArray(value)) {
        value.forEach((criteria, index) => {
          if (criteria.Scenarios && Array.isArray(criteria.Scenarios)) {
            formattedValue +=
              criteria.Scenarios.join("\n") +
              (index < value.length - 1 ? "\n\n" : "");
          }
        });
      }

      setEditValue(formattedValue);
    } else if (
      field === "non_functional_requirements" &&
      Array.isArray(value)
    ) {
      // Format non-functional requirements as newline-separated list

      setEditValue(value.join("\n"));
    } else {
      setEditValue(value);
    }
  };

  const handleSaveEdit = () => {
    if (editingStoryIndex >= 0 && editingField) {
      const updatedUserStories = { ...userStories };

      const updatedStoryList = [...updatedUserStories.user_story_list];

      if (editingField === "acceptanceCriteria") {
        // Parse edited text back into structured format

        const scenarios = editValue
          .split(/\n\s*\n/)
          .filter((group) => group.trim() !== "");

        const formattedCriteria = scenarios.map((group) => {
          const lines = group.split("\n").filter((line) => line.trim() !== "");

          return { Scenarios: lines };
        });

        updatedStoryList[editingStoryIndex][editingField] = formattedCriteria;
      } else if (editingField === "non_functional_requirements") {
        // Parse newline-separated text back into array

        const requirements = editValue

          .split("\n")

          .map((line) => line.trim())

          .filter((line) => line !== "");

        updatedStoryList[editingStoryIndex][editingField] = requirements;
      } else {
        // For simple string fields

        updatedStoryList[editingStoryIndex][editingField] = editValue;
      }

      updatedUserStories.user_story_list = updatedStoryList;

      setUserStories(updatedUserStories);
    }

    // Reset editing state

    setEditingStoryIndex(-1);

    setEditingField(null);

    setEditValue("");
  };

  const renderEditableField = (storyIndex, field, value, isArray = false) => {
    const isEditing =
      editingStoryIndex === storyIndex && editingField === field;

    if (isEditing) {
      return (
        <div className="w-full">
          <textarea
            className="w-full flex-1 p-2 text-gray-700 bg-transparent resize-none focus:outline-none min-h-[60px]"
            value={editValue}
            onChange={(e) => setEditValue(e.target.value)}
            rows={5}
          />

          <div
            className="bg-blue-200 flex justify-end px-2 cursor-pointer align-middle"
            style={{ borderRadius: "0px 0px 10px 10px" }}
            onClick={handleSaveEdit}
          >
            <div
              className="flex gap-1 justify-center align-middle rounded-xl p-1"
              style={{
                alignItems: "center",

                border: "1px solid #632678",
              }}
            >
              <SaveOutlinedIcon />
              Save
            </div>
          </div>
        </div>
      );
    }

    return (
      <div className="relative">
        {!isRunAuto && (
          <div
            className="absolute top-0 right-0 cursor-pointer"
            onClick={() => handleStartEditing(storyIndex, field, value)}
          >
            <div
              className="flex gap-1 justify-center align-middle rounded-xl p-1"
              style={{
                alignItems: "center",

                border: "1px solid #632678",

                background: "#e6f2ff",
              }}
            >
              <EditOutlinedIcon
                sx={{
                  width: "16px",

                  height: "16px",

                  margin: 0,

                  padding: 0,
                }}
              />
            </div>
          </div>
        )}

        {field === "user_story" ? (
          <Markdown>{value}</Markdown>
        ) : isArray ? (
          Array.isArray(value) &&
          value.map((item, idx) => <p key={idx}>{item}</p>)
        ) : (
          <div>{value}</div>
        )}
      </div>
    );
  };

  const renderAcceptanceCriteria = (storyIndex, criteria) => {
    const isEditing =
      editingStoryIndex === storyIndex && editingField === "acceptanceCriteria";

    if (isEditing) {
      return (
        <div className="w-full">
          <textarea
            className="w-full flex-1 p-2 text-gray-700 bg-transparent resize-none focus:outline-none min-h-[100px]"
            value={editValue}
            onChange={(e) => setEditValue(e.target.value)}
            rows={8}
            placeholder="Enter each scenario line by line. Separate different scenarios with a blank line."
          />

          <div
            className="bg-blue-200 flex justify-end px-2 cursor-pointer align-middle"
            style={{ borderRadius: "0px 0px 10px 10px" }}
            onClick={handleSaveEdit}
          >
            <div
              className="flex gap-1 justify-center align-middle rounded-xl p-1"
              style={{
                alignItems: "center",

                border: "1px solid #632678",
              }}
            >
              <SaveOutlinedIcon />
              Save
            </div>
          </div>
        </div>
      );
    }

    return (
      <div className="relative">
        {!isRunAuto && (
          <div
            className="absolute top-0 right-0 cursor-pointer"
            onClick={() =>
              handleStartEditing(storyIndex, "acceptanceCriteria", criteria)
            }
          >
            <div
              className="flex gap-1 justify-center align-middle rounded-xl p-1"
              style={{
                alignItems: "center",

                border: "1px solid #632678",

                background: "#e6f2ff",
              }}
            >
              <EditOutlinedIcon
                sx={{
                  width: "16px",

                  height: "16px",

                  margin: 0,

                  padding: 0,
                }}
              />
            </div>
          </div>
        )}

        {criteria.length > 0 &&
          criteria.map((criteriaItem, criteriaIndex) => (
            <div key={criteriaIndex} style={{ marginTop: "25px" }}>
              {criteriaItem?.Scenarios &&
                criteriaItem.Scenarios.length > 0 &&
                criteriaItem.Scenarios.map((scenario, scenarioIndex) => (
                  <li key={scenarioIndex}>{scenario}</li>
                ))}
            </div>
          ))}
      </div>
    );
  };

  return (
    <>
      <Box sx={{ paddingTop: "20px", paddingBottom: "10px" }}>
        <Typography variant="h6">Generated User-Stories</Typography>

        <Divider />
      </Box>

      <div
        className="flex flex-col gap-10 p-4 mt-1 max-h-96 overflow-auto bg-blue-100"
        style={{ fontFamily: ["poppins", "Karla", "sans-serif"].join(",") }}
      >
        {userStories?.user_story_list &&
          userStories?.user_story_list.map((item, index) => (
            <div key={index}>
              <Typography
                variant="h5"
                sx={{ fontSize: "14px", fontWeight: "600" }}
              >
                User Story
              </Typography>

              {renderEditableField(index, "user_story", item?.user_story)}

              <Typography
                variant="h5"
                sx={{ fontSize: "14px", fontWeight: "600", marginTop: "20px" }}
              >
                Acceptance Criteria
              </Typography>

              {renderAcceptanceCriteria(index, item?.acceptanceCriteria)}

              <Typography
                variant="h5"
                sx={{ fontSize: "14px", fontWeight: "600", marginTop: "20px" }}
              >
                Story Context
              </Typography>

              {renderEditableField(
                index,
                "context_of_the_story",
                item?.context_of_the_story
              )}

              <Typography
                variant="h5"
                sx={{ fontSize: "14px", fontWeight: "600", marginTop: "20px" }}
              >
                Story Description
              </Typography>

              {renderEditableField(index, "description", item?.description)}

              <Typography
                variant="h5"
                sx={{ fontSize: "14px", fontWeight: "600", marginTop: "20px" }}
              >
                Non Functional Requirements
              </Typography>

              {renderEditableField(
                index,
                "non_functional_requirements",
                item?.non_functional_requirements,
                true
              )}

              <Typography
                variant="h5"
                sx={{ fontSize: "14px", fontWeight: "600", marginTop: "20px" }}
              >
                Scope
              </Typography>

              {renderEditableField(index, "out_of_scope", item?.out_of_scope)}

              <Typography
                variant="h5"
                sx={{ fontSize: "14px", fontWeight: "600", marginTop: "20px" }}
              >
                Scalability
              </Typography>

              {renderEditableField(index, "scalability", item?.scalability)}

              <Typography
                variant="h5"
                sx={{ fontSize: "14px", fontWeight: "600", marginTop: "20px" }}
              >
                Security
              </Typography>

              {renderEditableField(index, "security", item?.security)}
            </div>
          ))}
      </div>

      {!isRunAuto && (
        <div className="mt-10 float-end flex gap-2">
          <Button
            onClick={() => handleGenerateBddTestScript()}
            sx={{ backgroundColor: "#632678" }}
            variant="contained"
          >
            Continue
          </Button>

          <Button
            onClick={() => handlePushToJira()}
            sx={{
              backgroundColor: isPushed ? "#cccccc" : "#10A2CE",
              cursor: isPushed ? "not-allowed" : "pointer",
            }}
            variant="contained"
            disabled={isPushed}
          >
            {isPushed ? "Pushed To Jira" : "Push To Jira"}
          </Button>
        </div>
      )}
    </>
  );
};

export default UserStory;
