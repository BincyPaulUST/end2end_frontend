import React, { useContext } from "react";

import {
  Box,
  Button,
  CircularProgress,
  Divider,
  Stack,
  Typography,
} from "@mui/material";
import KeyboardAltOutlinedIcon from "@mui/icons-material/KeyboardAltOutlined";
import SettingsSuggestOutlinedIcon from "@mui/icons-material/SettingsSuggestOutlined";
import AutoAwesomeOutlinedIcon from "@mui/icons-material/AutoAwesomeOutlined";
import IntegrationInstructionsOutlinedIcon from "@mui/icons-material/IntegrationInstructionsOutlined";
import AnalyticsOutlinedIcon from "@mui/icons-material/AnalyticsOutlined";
import DescriptionOutlinedIcon from "@mui/icons-material/DescriptionOutlined";

import { DataContext } from "../context/DataContext";
import JiraConfigDrawer from "./ConfigDrawer";
import { ConfigurationContext } from "../context/ConfigurationContext";

const steps = [
  "Input & Configuration",

  "Generate Requirements",

  "Generate User-Story",

  "Generate BDD",
  "Generate Test-Script",

  "Jira Integration",
];

const HorizontalLinearStepper = () => {
  const {
    activeStep,

    setActiveStep,

    requirementLoading,

    setRequirementLoading,

    userStoryLoading,
    bddLoading,
    setBddLoading,
    testCasesLoading,
    integrationStatus,
    fetchedContent,
    integration,
    testCases,
    bdd,
    requirements,
    userStories,
  } = React.useContext(DataContext);

  const {
    generateBDD,
    setGenerateBDD,
    generateTestScripts,
    setGenerateTestScripts,
    epicId,
    jiraSummary,
    jiraPrompt,
  } = useContext(ConfigurationContext);

  return (
    <Box
      sx={{
        height: "200px",
        boxSizing: "border-box",
        marginBottom: "30px",
      }}
    >
      <div className="float-end">
        <JiraConfigDrawer />
      </div>
      <Box sx={{ paddingTop: "20px", paddingBottom: "10px" }}>
        <Typography variant="h5">End To End Flow</Typography>
        <Divider />
      </Box>
      <Box
        sx={{
          width: "100%",
          boxSizing: "border-box",
          position: "relative",
          backgroundColor: "#F8F9F8",
          minHeight: "90px",
        }}
      >
        <Stack
          direction="row"
          alignItems="center"
          spacing={2}
          sx={{
            position: (generateBDD || generateTestScripts) && "absolute",
            top: -60,
            width: "100%",
            padding: "10px",
          }}
        >
          {steps.map((label, index) => (
            <React.Fragment key={label}>
              {/* Render "Generate User-Story" and "Generate BDD" in a vertical stack */}

              {index === 2 ? (
                <Stack
                  direction="column"
                  alignItems="center"
                  spacing={0}
                  className="relative"
                >
                  {/* "Generate User-Story" Box */}

                  <Box
                    sx={{
                      p: 1,

                      borderRadius: 1,

                      backgroundColor:
                        activeStep === index ||
                        Object.keys(userStories).length !== 0
                          ? "#10A2CE"
                          : "transparent",

                      color:
                        activeStep === index ||
                        Object.keys(userStories).length !== 0
                          ? "primary.contrastText"
                          : "text.primary",

                      cursor: "pointer",

                      textWrap: "nowrap",

                      margin: "0px",
                      gap: "5px",
                      marginTop: (generateBDD || generateTestScripts) && "70px",
                      zIndex: "996",
                      minWidth: "200px",
                      textAlign: "center",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      border: "1px solid black",
                    }}
                    onClick={() => setActiveStep(index)}
                  >
                    {index === 2 && <AutoAwesomeOutlinedIcon />}
                    <Typography>{label}</Typography>

                    {userStoryLoading && <CircularProgress size={20} />}
                  </Box>

                  {/* Vertical Line */}
                  {(generateBDD || generateTestScripts) && (
                    <Box
                      sx={{
                        height: "40px", // Adjust the height of the vertical line

                        width: "2px",

                        backgroundColor:
                          activeStep > index ? "#10A2CE" : "grey.300",
                        position: "relative",
                      }}
                    />
                  )}

                  {/* "Generate BDD" Box */}
                  {generateBDD && (
                    <Box
                      sx={{
                        p: 1,

                        borderRadius: 1,

                        backgroundColor:
                          activeStep === index + 1 ||
                          Object.keys(bdd).length !== 0
                            ? "#10A2CE"
                            : "transparent",

                        color:
                          activeStep === index + 1 ||
                          Object.keys(bdd).length !== 0
                            ? "primary.contrastText"
                            : "text.primary",

                        cursor: "pointer",

                        textWrap: "nowrap",

                        margin: "0px",

                        display: "flex",

                        gap: "5px",
                        zIndex: "999",
                        minWidth: "150px",
                        justifyContent: "center",
                        border: "1px solid black",
                      }}
                      onClick={() => setActiveStep(index + 1)}
                    >
                      {index + 1 === 3 && <AnalyticsOutlinedIcon />}
                      <Typography>{steps[index + 1]}</Typography>
                      {bddLoading && <CircularProgress size={20} />}
                    </Box>
                  )}
                  {generateBDD && generateTestScripts && (
                    <svg
                      width="200"
                      height="150"
                      className="absolute border-none left-10 top-4"
                    >
                      <polyline
                        points=" 70,120 200,120 200,135"
                        fill="none"
                        stroke={
                          activeStep > index + 1 ? "#10A2CE" : "lightgray"
                        }
                        strokeWidth="1.5"
                      />
                    </svg>
                  )}
                  {generateTestScripts && (
                    <Box
                      sx={{
                        p: 1,

                        borderRadius: 1,

                        backgroundColor:
                          activeStep === index + 2 ||
                          Object.keys(testCases).length !== 0
                            ? "#10A2CE"
                            : "transparent",

                        color:
                          activeStep === index + 2 ||
                          Object.keys(testCases).length !== 0
                            ? "primary.contrastText"
                            : "text.primary",

                        cursor: "pointer",

                        textWrap: "nowrap",

                        margin: "0px",

                        display: "flex",

                        gap: "5px",
                        position: generateBDD && "absolute",
                        top: "150px",
                        left: generateBDD ? "210px" : "0px",
                        border: "1px solid black",
                      }}
                      onClick={() => setActiveStep(index + 2)}
                    >
                      {index + 2 === 4 && <DescriptionOutlinedIcon />}
                      <Typography>{steps[index + 2]}</Typography>
                      {testCasesLoading && <CircularProgress size={20} />}
                    </Box>
                  )}
                </Stack>
              ) : index !== 3 && index !== 4 ? ( // Skip rendering "Generate BDD" separately
                <Box
                  sx={{
                    p: 1,

                    borderRadius: 1,

                    backgroundColor:
                      activeStep === index ||
                      (Object.keys(integration).length !== 0 && integration) ||
                      (index === 0 &&
                        fetchedContent !== "" &&
                        (epicId !== "" ||
                          (jiraPrompt !== "" && jiraSummary !== ""))) ||
                      (requirements !== "" && index === 1)
                        ? "#10A2CE"
                        : "transparent",

                    color:
                      activeStep === index ||
                      (Object.keys(integration).length !== 0 && integration) ||
                      (index === 0 &&
                        fetchedContent !== "" &&
                        (epicId !== "" ||
                          (jiraPrompt !== "" && jiraSummary !== ""))) ||
                      (requirements !== "" && index === 1)
                        ? "primary.contrastText"
                        : "text.primary",
                    cursor: "pointer",
                    textWrap: "nowrap",
                    margin: "0px",
                    display: "flex",
                    gap: "5px",
                    zIndex: "998",
                    alignItems: "center",
                    justifyContent: "center",
                    border: "1px solid black",
                  }}
                  onClick={() => setActiveStep(index)}
                >
                  {index === 0 ? (
                    <KeyboardAltOutlinedIcon />
                  ) : index === 1 ? (
                    <SettingsSuggestOutlinedIcon />
                  ) : (
                    <IntegrationInstructionsOutlinedIcon />
                  )}
                  <Typography>{label}</Typography>

                  {requirementLoading && index === 1 && (
                    <CircularProgress size={20} />
                  )}
                  {integrationStatus && index === 5 && (
                    <CircularProgress size={20} />
                  )}
                </Box>
              ) : null}

              {index < steps.length - 1 && index !== 2 && index !== 3 && (
                <Box
                  sx={{
                    height: 2,

                    width: "100%",

                    backgroundColor:
                      activeStep > index ? "#10A2CE" : "grey.300",
                  }}
                />
              )}
            </React.Fragment>
          ))}
        </Stack>
      </Box>
    </Box>
  );
};

export default HorizontalLinearStepper;
