import React, { useContext, useState } from "react";

import SendIcon from "@mui/icons-material/Send";
import { DataContext } from "../context/DataContext";
import { endToEndService } from "../services/EndToEndService";
import { CircularProgress } from "@mui/material";
import { ConfigurationContext } from "../context/ConfigurationContext";
import { ToastContainer, toast } from "react-toastify";

const ChatInput = () => {
  const { message, setMessage, setFetchedContent } = useContext(DataContext);
  const [loading, setLoading] = useState(false);
  const {
    epicId,
    setEpicId,
    jiraPrompt,
    setJiraPrompt,
    jiraSummary,
    selectedValue,
    setSelectedValue,
    generateBDD,
    generateTestScripts,
    setJiraSummary,
    isjiraSelected,
  } = useContext(ConfigurationContext);

  const handleSend = () => {
    if (isjiraSelected) {
      if (selectedValue === "Yes") {
        if (epicId === "") {
          toast.warn("Jira Epic Required !!!", {
            position: "top-right",
            autoClose: 2000,
            hideProgressBar: true,
            closeOnClick: false,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            theme: "light",
          });
          return;
        }
      } else {
        if (jiraPrompt === "" || jiraSummary === "") {
          toast.warn("Jira Epic Name and Summary Required !!!", {
            position: "top-right",
            autoClose: 2000,
            hideProgressBar: true,
            closeOnClick: false,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            theme: "light",
          });
          return;
        }
      }
    } else {
      toast.warn("Jira Configuration Required !!!", {
        position: "top-right",
        autoClose: 2000,
        hideProgressBar: true,
        closeOnClick: false,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
      return;
    }
    setFetchedContent("");
    const InputData = {
      query: message,
    };
    if (message.trim()) {
      setLoading(true);
      endToEndService
        .fetchFromRag(InputData)
        .then((data) => {
          console.log(data);
          setFetchedContent(data?.response);
        })
        .catch((error) => {
          console.error("Error:", error);
        })

        .finally(() => {
          setLoading(false);
        });

      setMessage("");
    }
  };

  return (
    <div className="mt-4">
      <ToastContainer
        position="top-right"
        autoClose={5000}
        hideProgressBar
        newestOnTop={false}
        closeOnClick={true}
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        theme="light"
        style={{ zIndex: "9999", marginTop: "100px" }}
      />
      <div className="flex items-end gap-3 bg-white rounded-2xl border shadow-sm p-2">
        <textarea
          className="flex-1 p-2 text-gray-700 bg-transparent resize-none focus:outline-none"
          placeholder="Type your query..."
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          rows={1}
        />

        <button
          onClick={handleSend}
          className={`p-2 rounded-xl transition-colors flex align-middle justify-center cursor-pointer`}
          style={{
            backgroundColor: message.trim() ? "#632678" : "lightgray",
          }}
        >
          {loading ? (
            <CircularProgress size={20} className="text-white" />
          ) : (
            <SendIcon
              size={20}
              className={message.trim() ? "text-white" : "text-gray-400"}
            />
          )}
        </button>
      </div>
    </div>
  );
};

export default ChatInput;
