import React, { useContext, useEffect, useState } from "react";
import ChatInput from "./InputItem";
import { DataContext } from "../context/DataContext";
import { Box, Button, Divider, Typography } from "@mui/material";
import Markdown from "react-markdown";
import EditOutlinedIcon from "@mui/icons-material/EditOutlined";
import SaveOutlinedIcon from "@mui/icons-material/SaveOutlined";
import Requirements from "./Requirements";
import { endToEndService } from "../services/EndToEndService";
import UserStory from "./UserStory";
import BDDComponent from "./BDDComponent";
import TestCaseComponent from "./TestCaseComponent";
import IntegrationComponent from "./IntegrationComponent";
import { ConfigurationContext } from "../context/ConfigurationContext";

const MainTabGroup = () => {
  const [isEditing, setIsEditing] = useState(false);
  const [isPushed, setIsPushed] = useState(false);
  const { fetchedContent, setFetchedContent } = useContext(DataContext);
  const {
    requirements,
    setRequirements,
    activeStep,
    setActiveStep,
    userStories,
    setUserStories,
    requirementLoading,
    setRequirementLoading,
    userStoryLoading,
    setUserStoryLoading,
    bdd,
    setBdd,
    bddLoading,
    setBddLoading,
    testCases,
    setTestCases,
    testCasesLoading,
    setTestCasesLoading,
    integration,
    setIntegration,
    integrationStatus,
    setIntegrationStatus,
  } = useContext(DataContext);

  const {
    epicId,
    setEpicId,
    jiraPrompt,
    setJiraPrompt,
    jiraSummary,
    selectedValue,
    setSelectedValue,
    generateBDD,
    generateTestScripts,
    setJiraSummary,
    isjiraSelected,
    isRunAuto,
  } = useContext(ConfigurationContext);

  const handlePushToJira = () => {
    if (!isRunAuto) {
      window.scrollTo({
        top: 0,
        behavior: "smooth",
      });
      setIntegration({});
    }
    const data = {
      userstories: userStories?.user_story_list,
      epicId: epicId,
      jiraSummary: jiraSummary,
      jiraPrompt: jiraPrompt,
    };
    console.log(data);
    setIntegrationStatus(true);
    endToEndService
      .FetchPushToJira(data)
      .then((data) => {
        console.log(data);
        setIntegration(data);
        setActiveStep(5);
        setIsPushed(true);
      })
      .catch((error) => {
        console.error("Error:", error);
      })
      .finally(() => {
        setIntegrationStatus(false);
      });
  };

  const handleGenerateTestCases = () => {
    if (!isRunAuto) {
      window.scrollTo({
        top: 0,
        behavior: "smooth",
      });
      setTestCases({});
    }
    const data = {
      userstories: userStories,
      language: "python",
      framework: "playWright",
    };
    console.log(data);
    setTestCasesLoading(true);
    endToEndService
      .FetchTestCases(data)
      .then((data) => {
        console.log(data);
        setTestCases(data);
        setActiveStep(4);
      })
      .catch((error) => {
        console.error("Error:", error);
      })

      .finally(() => {
        setTestCasesLoading(false);
      });
  };

  const handleGenerateBdd = () => {
    if (!isRunAuto) {
      window.scrollTo({
        top: 0,
        behavior: "smooth",
      });
      setBdd({});
    }
    const data = {
      userstories: userStories,
    };
    console.log(data);
    setBddLoading(true);
    endToEndService
      .FetchBdd(data)
      .then((data) => {
        console.log(data);
        setBdd(data);
        setActiveStep(3);
      })
      .catch((error) => {
        console.error("Error:", error);
      })

      .finally(() => {
        setBddLoading(false);
      });
  };

  useEffect(() => {
    if (
      Object.keys(bdd).length > 0 ||
      Object.keys(testCases).length > 0 ||
      Object.keys(integration).length > 0
    ) {
      return;
    }
    if (Object.keys(userStories).length > 0) {
      if (generateBDD && isRunAuto) {
        handleGenerateBdd();
      }
      if (generateTestScripts && isRunAuto) {
        handleGenerateTestCases();
      }
      if (isRunAuto) {
        handlePushToJira();
      }
    }
  }, [userStories]);

  const handleGenerateUserStories = () => {
    if (!isRunAuto) {
      window.scrollTo({
        top: 0,
        behavior: "smooth",
      });
      setUserStories({});
      setBdd({});
      setTestCases({});
      setIntegration({});
    }
    const data = {
      requirements: requirements?.requirements_generated
        ? requirements?.requirements_generated
        : "",
    };
    setUserStoryLoading(true);
    endToEndService
      .FetchUserStories(data)
      .then((data) => {
        console.log(data);
        setUserStories(data);
        setActiveStep(2);
      })
      .catch((error) => {
        console.error("Error:", error);
      })

      .finally(() => {
        setUserStoryLoading(false);
      });
  };

  useEffect(() => {
    if (isRunAuto && requirements) {
      handleGenerateUserStories();
    }
  }, [requirements, isRunAuto]);

  const handleGenerateRequirements = () => {
    const data = {
      summary: fetchedContent,
    };
    setRequirementLoading(true);
    endToEndService
      .FetchRequirements(data)
      .then((data) => {
        // console.log(data);
        setRequirements(data);
        setActiveStep(1);
      })
      .catch((error) => {
        console.error("Error:", error);
      })

      .finally(() => {
        setRequirementLoading(false);
      });
  };

  const runPipeline = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
    setRequirements("");
    setUserStories({});
    setBdd({});
    setTestCases({});
    setIntegration({});
    handleGenerateRequirements();
  };

  const handleClearData = () => {
    setFetchedContent("");
    setRequirements("");
    setUserStories({});
    setBdd({});
    setTestCases({});
    setIntegration({});
  };

  return (
    <>
      {fetchedContent && (
        <div>
          <Button
            onClick={() => handleClearData()}
            sx={{
              minWidth: "80px",
              textTransform: "capitalize",
              "&:hover": { backgroundColor: "#632678", color: "white" },
            }}
            variant="outlined"
          >
            Clear
          </Button>
        </div>
      )}
      {activeStep === 0 ? (
        <div className="bg-gradient-to-t from-gray-100 to-white p-2 mt-4">
          {fetchedContent && (
            <Box sx={{ paddingTop: "20px", paddingBottom: "10px" }}>
              <Typography variant="h6">Input Data</Typography>
              <Divider />
            </Box>
          )}
          <div
            className="flex gap-3 bg-white rounded-sm border shadow-sm p-2"
            style={{ fontFamily: ["poppins", "Karla", "sans-serif"].join(",") }}
          >
            <div className="relative w-full">
              {!isEditing && fetchedContent ? (
                <>
                  <Markdown className="bg-blue-100 p-2 max-h-96 overflow-auto">
                    {fetchedContent ? fetchedContent : ""}
                  </Markdown>
                  <div
                    className="bg-blue-200 flex justify-end px-2 cursor-pointer align-middle"
                    style={{ borderRadius: "0px 0px 10px 10px" }}
                    onClick={() => setIsEditing(true)}
                  >
                    <div
                      className="flex gap-1 justify-center align-middle rounded-xl p-1"
                      style={{
                        alignItems: "center",
                        border: "1px solid #632678",
                      }}
                    >
                      <EditOutlinedIcon
                        sx={{
                          width: "20px",
                          height: "20px",
                          margin: 0,
                          padding: 0,
                        }}
                      />
                      <p>Edit</p>
                    </div>
                  </div>
                </>
              ) : (
                <>
                  <textarea
                    className="w-full flex-1 p-4 text-gray-700 bg-transparent resize-none focus:outline-none min-h-[60px]"
                    value={fetchedContent ? fetchedContent : ""}
                    onChange={(e) => setFetchedContent(e.target.value)}
                    rows={fetchedContent ? 10 : 5}
                    disabled={!isEditing}
                  />
                  {(fetchedContent || isEditing) && (
                    <div
                      className="bg-blue-200 flex justify-end px-2 cursor-pointer align-middle"
                      style={{ borderRadius: "0px 0px 10px 10px" }}
                      onClick={() => setIsEditing(false)}
                    >
                      <div
                        className="flex gap-1 justify-center align-middle rounded-xl p-1"
                        style={{
                          alignItems: "center",
                          border: "1px solid #632678",
                        }}
                      >
                        <SaveOutlinedIcon />
                        Save
                      </div>
                    </div>
                  )}
                </>
              )}
              {!fetchedContent && !isEditing && (
                <>
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <Typography
                      variant="h5"
                      sx={{ fontWeight: 700, color: "lightgray" }}
                    >
                      Automate Your Requirement Workflow
                    </Typography>
                  </div>
                </>
              )}
            </div>
          </div>
          <ChatInput />

          {fetchedContent?.trim() && !isEditing && (
            <div className="mt-10 float-end">
              <Button
                onClick={() => runPipeline()}
                sx={{ backgroundColor: "#632678" }}
                variant="contained"
              >
                Continue
              </Button>
            </div>
          )}
        </div>
      ) : activeStep === 1 ? (
        <div>
          <Requirements handleGenerateUserStories={handleGenerateUserStories} />
        </div>
      ) : activeStep === 2 ? (
        <div>
          <UserStory
            handleGenerateBdd={handleGenerateBdd}
            handleGenerateTestCases={handleGenerateTestCases}
            handlePushToJira={handlePushToJira}
            isPushed={isPushed}
            setIsPushed={setIsPushed}
          />
        </div>
      ) : activeStep === 3 ? (
        <div>
          <BDDComponent />
        </div>
      ) : activeStep === 4 ? (
        <div>
          <TestCaseComponent />
        </div>
      ) : (
        <div>
          <IntegrationComponent />
        </div>
      )}
    </>
  );
};

export default MainTabGroup;
