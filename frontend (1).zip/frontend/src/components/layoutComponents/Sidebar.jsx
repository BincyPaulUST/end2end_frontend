import * as React from "react";
import { styled, useTheme } from "@mui/material/styles";
import Box from "@mui/material/Box";
import Drawer from "@mui/material/Drawer";
import CssBaseline from "@mui/material/CssBaseline";
import List from "@mui/material/List";
import Divider from "@mui/material/Divider";
import IconButton from "@mui/material/IconButton";
import ChevronLeftIcon from "@mui/icons-material/ChevronLeft";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";
import DriveFolderUploadOutlinedIcon from "@mui/icons-material/DriveFolderUploadOutlined";
import AutoGraphOutlinedIcon from "@mui/icons-material/AutoGraphOutlined";
import AccountTreeOutlinedIcon from "@mui/icons-material/AccountTreeOutlined";
import {
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
} from "@mui/material";
import { NavLink, useLocation } from "react-router-dom";

const DrawerHeader = styled("div")(({ theme }) => ({
  display: "flex",
  alignItems: "center",
  padding: theme.spacing(0, 1),
  ...theme.mixins.toolbar,
  justifyContent: "flex-end",
}));

export default function Sidebar() {
  const theme = useTheme();
  const [open, setOpen] = React.useState(true);

  const location = useLocation();

  const drawerWidth = open ? 230 : 70;

  const handleDrawer = () => {
    setOpen(!open);
  };

  return (
    <Box sx={{ display: "flex" }}>
      <CssBaseline />
      <Drawer
        variant="permanent"
        open={open}
        sx={{
          width: drawerWidth,
          flexShrink: 0,
          height: "100%",
          position: "relative",
          "& .MuiDrawer-paper": {
            width: drawerWidth,
            boxSizing: "border-box",
            transition: "width 0.3s ease",
            borderRight: "1px solid rgba(0,0,0,0.12)",
            backgroundColor: "white",
            position: "relative",
            height: "100%",
            overflowX: "hidden",
          },
        }}
        anchor="left"
      >
        <DrawerHeader>
          <IconButton onClick={handleDrawer}>
            {open ? <ChevronLeftIcon /> : <ChevronRightIcon />}
          </IconButton>
        </DrawerHeader>
        <Divider />
        <List>
          <NavLink to="/">
            <ListItem disablePadding sx={{ maxHeight: "50px", padding: "8px" }}>
              <ListItemButton
                sx={{
                  backgroundColor:
                    location.pathname === "/" ? "#632678" : "inherit", // Active background
                  color: location.pathname === "/" ? "white" : "inherit", // Active text

                  "&:hover": {
                    backgroundColor: "#632678",
                    color: "white",
                  },
                  maxHeight: "40px",
                }}
              >
                <ListItemIcon>
                  <AutoGraphOutlinedIcon
                    style={{
                      color: location.pathname === "/" ? "white" : "inherit",
                    }}
                  />
                </ListItemIcon>
                <ListItemText primary="End To End Flow" />
              </ListItemButton>
            </ListItem>
          </NavLink>
          {/* <NavLink to="/service/graph">
            <ListItem disablePadding sx={{ maxHeight: "50px", padding: "8px" }}>
              <ListItemButton
                sx={{
                  backgroundColor: location.pathname.includes("graph")
                    ? "#632678"
                    : "inherit",
                  color: location.pathname.includes("graph")
                    ? "white"
                    : "inherit",

                  "&:hover": {
                    backgroundColor: "#632678",
                    color: "white",
                  },
                  maxHeight: "40px",
                }}
              >
                <ListItemIcon>
                  <AccountTreeOutlinedIcon
                    style={{
                      color: location.pathname.includes("graph")
                        ? "white"
                        : "inherit",
                    }}
                  />
                </ListItemIcon>
                <ListItemText primary="Graph" />
              </ListItemButton>
            </ListItem>
          </NavLink> */}
          <NavLink to="/service/file-upload">
            <ListItem disablePadding sx={{ maxHeight: "50px", padding: "8px" }}>
              <ListItemButton
                sx={{
                  backgroundColor: location.pathname.includes("file-upload")
                    ? "#632678"
                    : "inherit",
                  color: location.pathname.includes("file-upload")
                    ? "white"
                    : "inherit",

                  "&:hover": {
                    backgroundColor: "#632678",
                    color: "white",
                  },
                  maxHeight: "40px",
                }}
              >
                <ListItemIcon>
                  <DriveFolderUploadOutlinedIcon
                    style={{
                      color: location.pathname.includes("file-upload")
                        ? "white"
                        : "inherit",
                    }}
                  />
                </ListItemIcon>
                <ListItemText primary="Upload Files" />
              </ListItemButton>
            </ListItem>
          </NavLink>
        </List>
        <Divider />
      </Drawer>
    </Box>
  );
}
