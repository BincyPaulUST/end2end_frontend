import React from "react";
import Logo from "../../assets/logo-main.png";

const Footer = () => {
  return (
    <div className="bg-black fixed bottom-0 left-0 right-0 z-90">
      {" "}
      <footer className="bg-black text-center flex">
        <div className="flex p-2">
          <img src={Logo} alt="main-icon" className="h-10 w-20 " fill="white" />
        </div>
        {/* <p className="text-sm">Footer</p> */}
      </footer>
    </div>
  );
};

export default Footer;
