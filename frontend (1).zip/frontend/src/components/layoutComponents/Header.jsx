import React, { useContext } from "react";
import Logo from "../../assets/logo-main.png";
import { Menu, MenuButton, MenuItem, MenuItems } from "@headlessui/react";
import { useNavigate } from "react-router-dom";
import UserIcon from "../../assets/account.svg";
import { AuthContext } from "../../context/AuthContext";

const Header = () => {
  const { user, logout } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <div className="fixed left-0 right-0 top-0 z-30">
      {" "}
      <header className="bg-gray-100 p-1 flex justify-between">
        <div className="align-middle flex justify-center p-2">
          <img
            src={Logo}
            alt="header-image"
            style={{ width: "80px", height: "40px" }}
          />
        </div>
        <Menu as="div" className="relative ml-3">
          <div>
            <MenuButton className="relative flex p-2 text-sm focus:outline-none focus:ring-offset-2">
              <span className="absolute -inset-1.5" />
              <span className="sr-only">Open user menu</span>
              <div className="flex flex-row justify-center align-middle m-auto">
                <img
                  src={UserIcon}
                  alt="user-icon"
                  style={{ width: "30px", height: "30px" }}
                />
                {/* <div className="font-medium p-2">{user?.name}</div> */}
              </div>
            </MenuButton>
          </div>
          <MenuItems
            transition
            className="absolute right-0 z-10 mt-2 w-48 origin-top-right rounded-md bg-white py-1 shadow-lg ring-1 ring-black/5 transition focus:outline-none data-[closed]:scale-95 data-[closed]:transform data-[closed]:opacity-0 data-[enter]:duration-100 data-[leave]:duration-75 data-[enter]:ease-out data-[leave]:ease-in"
          >
            <MenuItem>
              <a
                href="#"
                className="block px-4 py-2 text-sm text-gray-700 data-[focus]:bg-gray-100 data-[focus]:outline-none"
                onClick={handleLogout}
              >
                Sign out
              </a>
            </MenuItem>
          </MenuItems>
        </Menu>
      </header>
    </div>
  );
};

export default Header;
