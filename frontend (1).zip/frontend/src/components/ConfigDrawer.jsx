import * as React from "react";
import Box from "@mui/material/Box";
import Drawer from "@mui/material/Drawer";
import Typography from "@mui/material/Typography";
import Radio from "@mui/material/Radio";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import CloseIcon from "@mui/icons-material/Close";
import {
  Tabs,
  Tab,
  FormControlLabel,
  Checkbox,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
} from "@mui/material";
import TuneRoundedIcon from "@mui/icons-material/TuneRounded";
import JiraIcon from "../assets/jira.svg";
import { ConfigurationContext } from "../context/ConfigurationContext";
import { endToEndService } from "../services/EndToEndService";
import { ToastContainer, toast } from "react-toastify";

export default function JiraConfigDrawer() {
  const [open, setOpen] = React.useState(false);
  const [epics, setEpics] = React.useState({});
  const [tabIndex, setTabIndex] = React.useState(0);

  const {
    selectedValue,
    setSelectedValue,
    generateBDD,
    setGenerateBDD,
    generateTestScripts,
    setGenerateTestScripts,
    epicId,
    setEpicId,
    jiraPrompt,
    setJiraPrompt,
    jiraSummary,
    setJiraSummary,
    isjiraSelected,
    setIsJiraSelected,
    isRunAuto,
    setIsRunAuto,
  } = React.useContext(ConfigurationContext);

  React.useEffect(() => {
    endToEndService
      .FetchEpics()
      .then((response) => {
        // console.log(response);
        setEpics(response);
      })
      .catch((error) => {
        console.error("Error:", error);
      })

      .finally(() => {});
  }, [open]);

  const toggleDrawer = (newOpen) => () => {
    if (isjiraSelected)
      if (selectedValue === "Yes") {
        if (epicId === "") {
          toast.warn("Jira Epic Required !!!", {
            position: "top-right",
            autoClose: 2000,
            hideProgressBar: true,
            closeOnClick: false,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            theme: "light",
          });
          return;
        }
      } else {
        if (jiraPrompt === "" || jiraSummary === "") {
          toast.warn("Jira Epic Name and Summary Required !!!", {
            position: "top-right",
            autoClose: 2000,
            hideProgressBar: true,
            closeOnClick: false,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            theme: "light",
          });
          return;
        }
      }

    setOpen(newOpen);
  };

  const handleTabChange = (event, newTabIndex) => {
    setTabIndex(newTabIndex);
  };

  const handleChangeSelected = (event) => {
    const selectedOption = event.target.value;
    setSelectedValue(selectedOption);
    setJiraPrompt("");
    setJiraSummary("");
    setEpicId("");
  };

  const handleChangePrompt = (event) => {
    setJiraPrompt(event.target.value);
  };

  const handleChangeSummary = (event) => {
    setJiraSummary(event.target.value);
  };

  const handleChange = (event) => {
    setEpicId(event.target.value);
  };

  const DrawerList = (
    <Box
      sx={{
        width: "450px",
        padding: "10px",
      }}
      role="presentation"
    >
      <ToastContainer
        position="top-right"
        autoClose={5000}
        hideProgressBar
        newestOnTop={false}
        closeOnClick={false}
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        theme="light"
      />
      <CloseIcon
        sx={{
          fontSize: "24px", // Reduced font size
          float: "right",
          cursor: "pointer",
          color: "#632678",
        }}
        onClick={toggleDrawer(false)}
      />

      <Tabs
        value={tabIndex}
        onChange={handleTabChange}
        aria-label="Jira Config Tabs"
        sx={{
          "& .MuiTab-root": {
            borderBottom: "2px solid #10A2CE",
            fontSize: "14px",
            textTransform: "capitalize",
          }, // Reduced font size for tabs
        }}
        indicatorColor="#632678"
      >
        <Tab
          sx={{
            backgroundColor: tabIndex === 0 ? "#632678" : "transparent",
            "&.Mui-selected": {
              backgroundColor: "#632678",
              color: "white",
            },
          }}
          label="Integration"
        />
        <Tab
          sx={{
            backgroundColor: tabIndex === 1 ? "#632678" : "transparent",
            "&.Mui-selected": {
              backgroundColor: "#632678",
              color: "white",
            },
          }}
          label="Script Automation"
        />
      </Tabs>

      {tabIndex === 0 && (
        <div className="mt-5">
          <FormControlLabel
            sx={{
              padding: "5px",
              width: "100%",
              backgroundColor: "#f5f5f5",
              margin: "0px 5px",

              boxSizing: "border-box",

              borderRadius: "5px 5px 0px 0px",

              border: `${isjiraSelected ? "1px solid #0097AB" : "none"}`,

              borderBottom: "none",
            }}
            label="Jira"
            control={
              <div
                style={{
                  display: "flex",

                  alignItems: "center",

                  justifyContent: "center",

                  marginRight: "10px",
                }}
              >
                <Checkbox
                  checked={isjiraSelected}
                  name="jira"
                  onChange={() => setIsJiraSelected(!isjiraSelected)}
                  style={{
                    color: `${isjiraSelected ? "#0097AB" : "inherit"}`,
                  }}
                />

                <img style={{ height: "20px" }} alt="jiraicon" src={JiraIcon} />
              </div>
            }
          />
          {isjiraSelected && (
            <div
              style={{
                padding: "10px",

                backgroundColor: "#f5f5f5",

                margin: "0px 5px",

                boxSizing: "border-box",

                borderRadius: "0px 0px 5px 5px",

                border: `${isjiraSelected ? "1px solid #0097AB" : "none"}`,

                borderTop: "none",
                width: "100%",
              }}
            >
              <p>Have an Epic ID?</p>

              <div
                style={{ display: "flex", gap: "10px", marginBottom: "10px" }}
              >
                <div
                  style={{
                    padding: "5px 65px 5px 0px",

                    backgroundColor: "white",

                    borderRadius: "5px",

                    border: `${
                      selectedValue === "Yes" ? "1px solid #0097AB" : "none"
                    }`,
                  }}
                >
                  <Radio
                    style={{
                      color: selectedValue === "Yes" ? "#0097AB" : "inherit",
                    }}
                    checked={selectedValue === "Yes"}
                    onChange={handleChangeSelected}
                    value="Yes"
                    name="radio-buttons"
                    inputProps={{ "aria-label": "Yes" }}
                  />
                  Yes
                </div>

                <div
                  style={{
                    padding: "5px 65px 5px 0px",

                    backgroundColor: "white",

                    borderRadius: "5px",

                    border: `${
                      selectedValue === "No" ? "1px solid #0097AB" : "none"
                    }`,
                  }}
                >
                  <Radio
                    style={{
                      color: selectedValue === "No" ? "#0097AB" : "inherit",
                    }}
                    checked={selectedValue === "No"}
                    onChange={handleChangeSelected}
                    value="No"
                    name="radio-buttons"
                    inputProps={{ "aria-label": "No" }}
                  />
                  No
                </div>
              </div>

              {selectedValue === "Yes" ? (
                <div
                  style={{
                    display: "flex",

                    gap: "10px",

                    justifyContent: "space-between",
                  }}
                >
                  <FormControl
                    sx={{ m: 1, minWidth: 120, width: "100%" }}
                    size="small"
                  >
                    <InputLabel id="demo-select-small-label">
                      Select Epic
                    </InputLabel>
                    <Select
                      labelId="demo-select-small-label"
                      id="demo-select-small"
                      value={epicId}
                      label="Select Epic"
                      onChange={handleChange}
                    >
                      {epics?.epics &&
                        epics?.epics.map((item) => (
                          <MenuItem key={item.key} value={item.key}>
                            {item.summary}
                          </MenuItem>
                        ))}
                    </Select>
                  </FormControl>
                </div>
              ) : (
                <div
                  style={{
                    display: "flex",

                    gap: "10px",

                    justifyContent: "space-between",

                    flexDirection: "column",
                  }}
                >
                  <TextField
                    id="outlined-basic"
                    label="Epic Name"
                    defaultValue={jiraPrompt}
                    variant="outlined"
                    onChange={(e) => handleChangePrompt(e)}
                    style={{ minWidth: "300px" }}
                  />

                  <TextField
                    id="outlined-basic"
                    label="Summary"
                    multiline
                    rows={4}
                    variant="outlined"
                    defaultValue={jiraSummary}
                    onChange={(e) => handleChangeSummary(e)}
                  />
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {tabIndex === 1 && (
        <Box
          sx={{
            maxHeight: "350px", // Maximum height of the container
            minHeight: "342px",
            border: "1px solid #cccc", // Border around the container
            overflowY: "auto", // Enables scrolling if content overflows
            padding: "10px", // Optional padding for spacing
            textTransform: "capitalize",
            marginTop: "20px",
            borderRadius: "5px",
          }}
        >
          <Typography
            sx={{ fontSize: "16px", marginBottom: "10px" }}
            variant="h6"
          >
            BDD Configuration
          </Typography>

          <Box
            sx={{
              border: generateBDD ? "2px solid teal" : "none", // Conditional border for generateBDD
              padding: "10px", // Padding when border is present
              borderRadius: "4px", // Optional rounded corners for the border
            }}
          >
            <FormControlLabel
              control={
                <Checkbox
                  checked={generateBDD}
                  onChange={() => setGenerateBDD(!generateBDD)}
                />
              }
              label={
                <Typography sx={{ fontSize: "14px" }}>Generate BDD</Typography>
              }
              sx={{ width: "100%" }}
            />
          </Box>

          <Typography
            variant="h6"
            sx={{ fontSize: "16px", marginTop: "20px", marginBottom: "10px" }}
          >
            Script Generation Configuration
          </Typography>

          <Box
            sx={{
              border: generateTestScripts ? "2px solid teal" : "none", // Conditional border for generateTestScripts
              padding: "10px", // Padding when border is present
              borderRadius: "4px", // Optional rounded corners for the border
            }}
          >
            <FormControlLabel
              control={
                <Checkbox
                  checked={generateTestScripts}
                  onChange={() => setGenerateTestScripts(!generateTestScripts)}
                />
              }
              label={
                <Typography sx={{ fontSize: "14px" }}>
                  Generate Playwright Scripts
                </Typography>
              }
              sx={{ width: "100%" }}
            />
          </Box>
        </Box>
      )}

      <Box
        sx={{
          border: isRunAuto ? "2px solid teal" : "none", // Conditional border for generateTestScripts
          padding: "10px", // Padding when border is present
          borderRadius: "4px", // Optional rounded corners for the border
          position: "fixed",
          bottom: 0,
        }}
      >
        <FormControlLabel
          control={
            <Checkbox
              checked={isRunAuto}
              onChange={() => setIsRunAuto(!isRunAuto)}
            />
          }
          label={
            <Typography sx={{ fontSize: "14px" }}>Run Automatically</Typography>
          }
          sx={{ width: "100%" }}
        />
      </Box>
      <Button
        sx={{
          position: "fixed",
          bottom: 0,
          right: 0,
          backgroundColor: "#632678",
          color: "white",
          margin: "10px",
        }}
        onClick={toggleDrawer(false)}
      >
        Save
      </Button>
    </Box>
  );

  return (
    <div>
      <Button
        sx={{
          textTransform: "capitalize",
          "&:hover": {
            backgroundColor: "#632678",
            color: "white",
          },
          zIndex: "999",
        }}
        onClick={toggleDrawer(true)}
        startIcon={<TuneRoundedIcon />}
      >
        Configuration
      </Button>
      <Drawer anchor="right" open={open} onClose={toggleDrawer(false)}>
        {DrawerList}
      </Drawer>
    </div>
  );
}
