import React, { useContext } from "react";
import { DataContext } from "../context/DataContext";
import SyntaxHighlighter from "react-syntax-highlighter";
import { docco } from "react-syntax-highlighter/dist/esm/styles/hljs";
import { Box, Divider, Typography } from "@mui/material";
import Markdown from "react-markdown";
import { WidthFull } from "@mui/icons-material";

const TestCaseComponent = () => {
  const { testCases, setTestCases } = useContext(DataContext);
  return (
    <>
      <Box sx={{ paddingTop: "20px", paddingBottom: "10px" }}>
        <Typography variant="h6">Generated Test Script</Typography>
        <Divider />
      </Box>
      <div className="box-border w-[100%] max-w-4xl max-h-96 overflow-auto">
        <SyntaxHighlighter style={docco}>
          {testCases?.testCases}
        </SyntaxHighlighter>
      </div>
    </>
  );
};

export default TestCaseComponent;
