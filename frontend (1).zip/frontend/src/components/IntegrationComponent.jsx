import React, { useContext } from "react";
import { DataContext } from "../context/DataContext";
import { Box, Divider, Typography } from "@mui/material";

const IntegrationComponent = () => {
  const { integration, setIntegration } = useContext(DataContext);
  return (
    <>
      <Box sx={{ paddingTop: "20px", paddingBottom: "10px" }}>
        <Typography variant="h6">Integration Status</Typography>
        <Divider />
      </Box>
      <div className="p-4 bg-blue-100 mt-6 max-h-96 overflow-auto text-sm">
        {integration?.details?.length > 0 && (
          <div>
            <Typography sx={{ fontSize: "16px", fontWeight: "600" }}>
              {integration?.message}
            </Typography>
            <div className="flex flex-row flex-wrap gap-3 mt-3">
              {integration?.details.map((item) => (
                <div
                  className="flex flex-col p-2 rounded-xl"
                  style={{ border: "1px solid black" }}
                >
                  <div className="flex gap-1">
                    <p>Issue Id:</p>
                    <p className="bg-blue-400 rounded-2xl p-1 text-white">
                      {item?.issue?.key}
                    </p>
                  </div>
                  <div className="flex gap-1">
                    <p>Issue Key:</p>
                    <p>{item?.issue?.id}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default IntegrationComponent;
