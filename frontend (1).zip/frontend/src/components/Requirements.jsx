import React, { useContext, useState } from "react";
import { DataContext } from "../context/DataContext";
import Markdown from "react-markdown";
import { Box, Button, Divider, Typography } from "@mui/material";
import { ConfigurationContext } from "../context/ConfigurationContext";
import EditOutlinedIcon from "@mui/icons-material/EditOutlined";
import SaveOutlinedIcon from "@mui/icons-material/SaveOutlined";

const Requirements = ({ handleGenerateUserStories }) => {
  const { requirements, setRequirements } = useContext(DataContext);
  const { isRunAuto } = useContext(ConfigurationContext);
  const [isEditing, setIsEditing] = useState(false);
  return (
    <>
      {" "}
      <Box sx={{ paddingTop: "20px", paddingBottom: "10px" }}>
        <Typography variant="h6">Generated Requirements</Typography>
        <Divider />
      </Box>
      {isEditing ? (
        <>
          <textarea
            className="w-full flex-1 p-4 text-gray-700 bg-transparent resize-none focus:outline-none min-h-[60px]"
            value={requirements?.requirements_generated || ""}
            onChange={(e) =>
              setRequirements({
                ...requirements, // Keep other keys unchanged

                requirements_generated: e.target.value, // Update only this key
              })
            }
            rows={10}
          />
          {isEditing && (
            <div
              className="bg-blue-200 flex justify-end px-2 cursor-pointer align-middle"
              style={{ borderRadius: "0px 0px 10px 10px" }}
              onClick={() => setIsEditing(false)}
            >
              <div
                className="flex gap-1 justify-center align-middle rounded-xl p-1"
                style={{
                  alignItems: "center",
                  border: "1px solid #632678",
                }}
              >
                <SaveOutlinedIcon />
                Save
              </div>
            </div>
          )}
        </>
      ) : (
        <div
          style={{
            borderRadius: "0px 0px 10px 10px",
            fontFamily: ["poppins", "Karla", "sans-serif"].join(","),
          }}
        >
          {requirements?.requirements_generated && (
            <>
              <div className="p-4 bg-blue-100 mt-1 max-h-96 overflow-auto">
                <Markdown>{requirements.requirements_generated}</Markdown>
              </div>
              {!isRunAuto && (
                <>
                  {!isEditing && (
                    <div
                      className="bg-blue-200 flex justify-end px-2 cursor-pointer align-middle"
                      style={{ borderRadius: "0px 0px 10px 10px" }}
                      onClick={() => setIsEditing(true)}
                    >
                      <div
                        className="flex gap-1 justify-center align-middle rounded-xl p-1"
                        style={{
                          alignItems: "center",
                          border: "1px solid #632678",
                        }}
                      >
                        <EditOutlinedIcon
                          sx={{
                            width: "20px",
                            height: "20px",
                            margin: 0,
                            padding: 0,
                          }}
                        />
                        <p>Edit</p>
                      </div>
                    </div>
                  )}
                </>
              )}
            </>
          )}
        </div>
      )}
      {!isRunAuto && !isEditing && (
        <div className="mt-10 float-end">
          <Button
            onClick={() => handleGenerateUserStories()}
            sx={{ backgroundColor: "#632678" }}
            variant="contained"
          >
            Continue
          </Button>
        </div>
      )}
    </>
  );
};

export default Requirements;
