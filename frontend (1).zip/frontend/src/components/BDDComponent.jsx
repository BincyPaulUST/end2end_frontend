import React, { useContext } from "react";
import { DataContext } from "../context/DataContext";
import Markdown from "react-markdown";
import { Box, Button, Divider, Typography } from "@mui/material";

const BDDComponent = () => {
  const { bdd, setBdd } = useContext(DataContext);
  return (
    <>
      {" "}
      <Box sx={{ paddingTop: "20px", paddingBottom: "10px" }}>
        <Typography variant="h6">Generated BDD-Scripts</Typography>
        <Divider />
      </Box>
      <div
        className="p-4 bg-blue-100 mt-1 max-h-96 overflow-auto"
        style={{
          borderRadius: "0px 0px 10px 10px",
          fontFamily: ["poppins", "Karla", "sans-serif"].join(","),
        }}
      >
        {bdd?.bdd_script &&
          bdd?.bdd_script.map((script) => (
            <div className="mb-5">
              <p>{script?.Feature}</p>{" "}
              {script?.Scenarios.length > 0 &&
                script?.Scenarios.map((scenario) => <li>{scenario}</li>)}
            </div>
          ))}
      </div>
    </>
  );
};

export default BDDComponent;
